package andy.memcache;

import java.util.ArrayList;
import java.util.List;

import com.alibaba.fastjson.JSONObject;

import andy.entity.User;

/**
 * @author Andy<andy_513@163.com>
 */
public class XMemcacheCache {
	
	public static void main(String[] args) throws Exception {
		List<User> users = new ArrayList<User>();
		XMemcacheUtil.flushAll();
		long time = System.currentTimeMillis();
		for (int i = 0; i < 10000; i++) {
			users.add(new User(i, "" + i));
		}
		String key = "a";
		XMemcacheUtil.addList(key, users);
		System.out.println(System.currentTimeMillis() - time);
		/*List<User> us = */XMemcacheUtil.getList(key);
		System.out.println(System.currentTimeMillis() - time);
		users.clear();
		for (int i = 0; i < 10000; i++) {
			users.add(new User(i, "a"));
		}
		XMemcacheUtil.setList(key, users);
		System.out.println(System.currentTimeMillis() - time);
//		List<User> lists = XMemcacheUtil.getList(key);
		User user = new User();
		user.setId(4);
		System.out.println(JSONObject.toJSONString(XMemcacheUtil.get(key, user)));
		System.out.println(System.currentTimeMillis() - time);
		/*for(int i = 0;i<us.size();i++){
			if (99999 == us.get(i).getId()) {
				user = us.get(i);
				break;
			}
		}
		System.out.println(JSONObject.toJSONString(user));
		System.out.println(System.currentTimeMillis() - time);*/
		/*System.out.println(lists.size() + "\t" + JSONObject.toJSONString(XMemcacheUtil.getList(key)));*/
	}

}
