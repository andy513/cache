package andy.memcache;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import andy.common.PropertiesUtil;
import andy.entity.User;
import net.rubyeye.xmemcached.MemcachedClient;
import net.rubyeye.xmemcached.MemcachedClientBuilder;
import net.rubyeye.xmemcached.XMemcachedClientBuilder;
import net.rubyeye.xmemcached.command.BinaryCommandFactory;
import net.rubyeye.xmemcached.exception.MemcachedException;
import net.rubyeye.xmemcached.impl.KetamaMemcachedSessionLocator;
import net.rubyeye.xmemcached.transcoders.SerializingTranscoder;
import net.rubyeye.xmemcached.utils.AddrUtil;

/**
 * @author Andy<andy_513@163.com>
 */
public class XMemcacheUtil {

	private static final Lock lock = new ReentrantLock();
	private static final String host = PropertiesUtil.getString("memcached.host");
	private static final int[] weight = PropertiesUtil.getIntArray("memcached.weight");
	private static final MemcachedClientBuilder builder = new XMemcachedClientBuilder(AddrUtil.getAddresses(host), weight);
	private static MemcachedClient client = null;

	static {
		try {
			// 使用二进制文件
			builder.setCommandFactory(new BinaryCommandFactory());
			// 使用一致性哈希算法（Consistent Hash Strategy）
			builder.setSessionLocator(new KetamaMemcachedSessionLocator());
			// 使用序列化传输编码
			builder.setTranscoder(new SerializingTranscoder());
			// 进行数据压缩，大于1KB时进行压缩
			builder.getTranscoder().setCompressionThreshold(1024);
			builder.setFailureMode(true);
			builder.setConnectionPoolSize(50);
			builder.setConnectTimeout(1000);
			client = builder.build();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static final void shutdown() {
		try {
			client.shutdown();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
	}

	public static final <T> void set(String key, T value) throws TimeoutException, InterruptedException, MemcachedException {
		set(key, value, 0);
	}

	public static final <T> void set(String key, T value, int exp) throws TimeoutException, InterruptedException, MemcachedException {
		if (value != null) {
			client.set(key, exp, value);
		}
	}

	public static final void del(String key) throws TimeoutException, InterruptedException, MemcachedException {
		client.delete(key);
	}

	public static final <T> T get(String key) throws TimeoutException, InterruptedException, MemcachedException {
		return client.get(key);
	}

	private static final <T> boolean addT(T t, String key, boolean bool) throws TimeoutException, InterruptedException, MemcachedException {
		List<T> lists = null;
		if (t instanceof List) {
			lists = (List<T>) t;
		} else {
			lists = new ArrayList<T>();
			lists.add(t);
		}
		return add(lists, key, bool);
	}

	public static final void flushAll() {
		try {
			client.flushAll();
			System.out.println("缓存删除成功");
		} catch (TimeoutException | InterruptedException | MemcachedException e) {
			e.printStackTrace();
		}
	}

	private static final <T> boolean add(List<T> lists, String key, boolean bool) throws TimeoutException, InterruptedException, MemcachedException {
		Lock l = lock;
		l.lock();
		try {
			List<T> ts = get(key);
			if (ts == null) {
				return client.set(key, 0, lists);
			} else {
				if (bool) {
					ts.addAll(lists);
				} else {
					List<T> old_lists = new ArrayList<T>();
					old_lists.addAll(lists);
					int max_size = ts.size();
					for (int i = 0; i < max_size; i++) {
						T ti = ts.get(i);
						int j = 0;
						while (j < old_lists.size()) {
							T tj = old_lists.get(j);
							if (ti.equals(tj)) {
								ts.set(i, tj);
								old_lists.remove(j);
								break;
							}
							j++;
						}
					}
				}
				return client.set(key, 0, ts);
			}
		} finally {
			l.unlock();
		}
	}

	public static final <T> boolean addList(String key, T t) throws TimeoutException, InterruptedException, MemcachedException {
		return addT(t, key, true);
	}

	public static final User get(String key, User user) throws Exception {
		return client.get(key + "_" + user.hashCode());
	}

	public static final Map<String, User> getList(String key) throws Exception {
		Collection<String> lists = client.get(key);
		Map<String, User> maps = client.get(lists);
		return maps;
	}
	
	/*public static void main(String[] args) {
		client.get(keyCollections)
	}*/

	public static final <T> void addList(String key, List<T> obj) throws Exception {
		List<String> lists = new ArrayList<>();
		for (int i = 0; i < obj.size(); i++) {
			T o = obj.get(i);
			int code = o.hashCode();
			String new_key = key + "_" + code;
			lists.add(new_key);
			client.add(new_key, 0, o);
		}
		client.add(key, 0, lists);
	}

	public static final <T> void setList(String key, List<T> obj) throws Exception {
		for (int i = 0; i < obj.size(); i++) {
			Object o = obj.get(i);
			int code = o.hashCode();
			String new_key = key + "_" + code;
			client.set(new_key, 0, o);
		}
	}

	public static final <T> boolean setList(String key, T t) throws TimeoutException, InterruptedException, MemcachedException {
		return addT(t, key, false);
	}

	public static final <T> void delList(String key, List<T> lists) throws TimeoutException, InterruptedException, MemcachedException {
		List<T> ts = get(key);
		if (ts != null) {
			ts.removeAll(lists);
			set(key, ts);
		}
	}

	public static final <T> void delList(String key, T t) throws TimeoutException, InterruptedException, MemcachedException {
		List<T> ts = get(key);
		if (ts != null) {
			ts.remove(t);
			set(key, ts);
		}
	}

}
